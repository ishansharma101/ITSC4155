create database if not exists Trend_UNCC;
use Trend_UNCC;

CREATE TABLE IF NOT EXISTS User_Profile (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    birthdate DATE,
    location VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS Events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255),
    event_description TEXT,
    event_date DATE,
    location VARCHAR(255),
    organizer_id INT,
    FOREIGN KEY (organizer_id) REFERENCES User_Profile(user_id)
);

CREATE TABLE IF NOT EXISTS Message_Board (
    message_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT,
    user_id INT,
    message TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES Events(event_id),
    FOREIGN KEY (user_id) REFERENCES User_Profile(user_id)
);

